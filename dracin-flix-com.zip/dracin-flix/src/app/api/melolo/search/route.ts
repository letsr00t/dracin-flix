import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";

export const dynamic = 'force-dynamic';

const MELOLO_HEADERS = {
  "User-Agent": "com.worldance.drama/49819 (Linux; U; Android 13; in; SM-A042F; Build/TP1A.220624.014; Cronet/TTNetVersion:8f366453 2024-12-24 QuicVersion:ef6c341e 2024-11-14)",
  "Accept": "application/json; charset=utf-8,application/x-protobuf",
  "Accept-Encoding": "gzip, deflate",
  "x-xs-from-web": "false",
  "age-range": "8",
};

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get("query");
  const limit = searchParams.get("limit") || "10";
  const offset = searchParams.get("offset") || "0";

  if (!query) {
    return encryptedResponse({ error: "Query parameter is required" }, 400);
  }

  try {
    const url = `https://api.tmtreader.com/i18n_novel/search/page/v1/?search_source_id=clks%23%23%23&IsFetchDebug=false&offset=${offset}&cancel_search_category_enhance=false&query=${encodeURIComponent(query)}&limit=${limit}&time_zone=Asia%2FMakassar&search_id&iid=7604173033750415125&device_id=7554232785717380664&ac=mobile&channel=gp&aid=645713&app_name=Melolo&version_code=51617&version_name=5.1.6&device_platform=android&os=android&ssmix=a&device_type=SM-A042F&device_brand=samsung&language=in&os_api=33&os_version=13&openudid=d7ad3f25422073a0&manifest_version_code=51617&resolution=720*1465&dpi=300&update_version_code=51617&_rticket=1770487297418&current_region=ID&carrier_region=id&app_language=id&sys_language=in&app_region=ID&prefer_gd=0&sys_region=ID&mcc_mnc=51001&carrier_region_v2=510&user_language=id&ui_language=in&cdid=245817c0-0db2-4417-9483-e535ug421t12`;
    const response = await fetch(url, { headers: MELOLO_HEADERS, cache: 'no-store' });
    const data = await response.json();
    return encryptedResponse(data);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return encryptedResponse({ error: message }, 500);
  }
}
