import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";

export const dynamic = 'force-dynamic';

const MELOLO_HEADERS = {
  "Accept": "application/json; charset=utf-8,application/x-protobuf",
  "Accept-Encoding": "gzip, deflate",
  "x-xs-from-web": "false",
  "age-range": "8",
};

export async function GET(request: NextRequest) {
  try {
    const url = "https://api.tmtreader.com/i18n_novel/search/front_page/v1/?feature_switch=%7B%22enable_drama_infinite_filter%22%3Afalse%2C%22enable_filter_page%22%3Atrue%7D&last_query=cinta&time_zone=Asia%2FMakassar&iid=7604173033750415125&device_id=7554232785717380664&ac=mobile&channel=gp&aid=645713&app_name=Melolo&version_code=51617&version_name=5.1.6&device_platform=android&os=android&ssmix=a&device_type=SM-A042F&device_brand=samsung&language=in&os_api=33&os_version=13&openudid=d7ad3f25422073a0&manifest_version_code=51617&resolution=720*1465&dpi=300&update_version_code=51617&_rticket=1770487572288&current_region=ID&carrier_region=id&app_language=id&sys_language=in&app_region=ID&prefer_gd=0&sys_region=ID&mcc_mnc=51001&carrier_region_v2=510&user_language=id&ui_language=in&cdid=245817c0-0db2-4417-9483-e535ug421t12";
    const response = await fetch(url, { headers: MELOLO_HEADERS, cache: 'no-store' });
    const json = await response.json();
    return encryptedResponse(json.data?.[0] ?? {});
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return encryptedResponse({ error: message }, 500);
  }
}
