import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const shortPlayId = searchParams.get("shortPlayId");

    if (!shortPlayId) {
      return encryptedResponse({ success: false, error: "shortPlayId is required" }, 400);
    }

    const data = await netshortFetch(
      `/web/v4/short_play/detail_info/cascade_label?shortPlayId=${shortPlayId}`
    );

    const raw = data?.data || data;
    const episodes = (raw?.shortPlayEpisodeInfos || raw?.episodeList || []).map((ep: any) => ({
      episodeId: ep.episodeId,
      episodeNo: ep.episodeNo,
      cover: ep.episodeCover,
      videoUrl: ep.playVoucher || ep.videoUrl,
      quality: ep.playClarity || "720p",
      isLock: ep.isLock,
      likeNums: ep.likeNums,
      subtitleUrl: ep.subtitleList?.[0]?.url || "",
    }));

    return encryptedResponse({
      success: true,
      shortPlayId: raw?.shortPlayId,
      shortPlayLibraryId: raw?.shortPlayLibraryId,
      title: raw?.shortPlayName,
      cover: raw?.shortPlayCover,
      description: raw?.shotIntroduce,
      labels: raw?.shortPlayLabels || raw?.labelList?.map((l: any) => l.labelName) || [],
      totalEpisodes: raw?.totalEpisode,
      isFinish: raw?.isFinish === 1,
      payPoint: raw?.payPoint,
      episodes,
    });
  } catch (error) {
    console.error("NetShort Detail Error:", error);
    return encryptedResponse({ success: false, error: "Internal server error" });
  }
}
