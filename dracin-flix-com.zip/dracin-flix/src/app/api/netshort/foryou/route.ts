import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    // NetShort homepage uses localStorage cache, no direct foryou API
    // Use queryOnlineLabelList as foryou/home content instead
    const data = await netshortFetch(`/web/web/v3/queryOnlineLabelList/cascade_label`);

    // Extract all dramas from all groups
    const list = data?.data || data || [];
    let dramas: any[] = [];

    if (Array.isArray(list)) {
      list.forEach((group: any) => {
        const items = group.contentInfos || group.shortPlayList || [];
        items.forEach((item: any) => {
          dramas.push({
            shortPlayId: item.shortPlayId,
            shortPlayLibraryId: item.shortPlayLibraryId,
            title: item.shortPlayName,
            cover: item.shortPlayCover || item.groupShortPlayCover,
            labels: item.labelArray || item.labelNameList || [],
            heatScore: item.heatScoreShow || "",
            scriptName: item.scriptName,
          });
        });
      });
    }

    // Deduplicate by shortPlayId
    const seen = new Set();
    dramas = dramas.filter((d) => {
      if (seen.has(d.shortPlayId)) return false;
      seen.add(d.shortPlayId);
      return true;
    });

    return encryptedResponse({
      success: true,
      data: dramas,
      completed: true,
    });
  } catch (error) {
    console.error("NetShort ForYou Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
