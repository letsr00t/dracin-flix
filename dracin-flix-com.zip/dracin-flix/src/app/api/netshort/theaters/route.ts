import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const data = await netshortFetch(`/web/web/v3/queryOnlineLabelList/cascade_label`);

    const list = data?.data || data || [];
    const normalizedGroups = Array.isArray(list) ? list.map((group: any) => ({
      groupId: group.groupId || group.labelId,
      groupName: group.contentName || group.labelName || group.groupName,
      contentRemark: group.contentRemark,
      dramas: (group.contentInfos || group.shortPlayList || []).map((item: any) => ({
        shortPlayId: item.shortPlayId,
        shortPlayLibraryId: item.shortPlayLibraryId,
        title: item.shortPlayName,
        cover: item.shortPlayCover || item.groupShortPlayCover,
        labels: item.labelArray || [],
        heatScore: item.heatScoreShow || "",
        scriptName: item.scriptName,
        totalEpisodes: item.totalEpisode || 0,
      })),
    })) : [];

    return encryptedResponse({ success: true, data: normalizedGroups });
  } catch (error) {
    console.error("NetShort Theaters Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
