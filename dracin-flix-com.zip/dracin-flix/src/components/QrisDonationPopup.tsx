"use client";

import { useState, useEffect } from "react";
import Image from "next/image";

export default function QrisDonationPopup() {
  const [isVisible, setIsVisible] = useState(false);
  const [countdown, setCountdown] = useState(10);

  useEffect(() => {
    setIsVisible(true);
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in duration-300">
      <div className="rounded-3xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col items-center p-6 border border-red-900/40 animate-in zoom-in-95 duration-500"
        style={{
          background: "linear-gradient(160deg, #1a0000 0%, #0a0000 60%, #000000 100%)",
          boxShadow: "0 0 40px rgba(180,0,0,0.25), 0 20px 60px rgba(0,0,0,0.8)"
        }}>

        {/* Red glow accent top */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 rounded-full" 
          style={{ background: "linear-gradient(90deg, transparent, #cc0000, transparent)" }} />

        {/* Header */}
        <div className="text-center space-y-3 mb-6">
          <h2 className="text-2xl font-black"
            style={{
              background: "linear-gradient(135deg, #ff2222 0%, #cc0000 50%, #880000 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text"
            }}>
            Dukung Penambahan Platform Drama Lain!
          </h2>
          <p className="text-sm font-medium leading-relaxed" style={{ color: "#c0a0a0" }}>
            Donasi kamu sangat berarti untuk menambah platform drama lain dan membayar tagihan bulanan{" "}
            <b style={{ color: "#ff4444" }}>(Dracin-Flix)</b> agar tetap aktif.
          </p>
        </div>

        {/* QRIS Image */}
        <div className="relative w-56 h-56 rounded-2xl overflow-hidden shadow-lg transition-transform hover:scale-105 duration-300 bg-white"
          style={{ border: "2px solid #550000" }}>
          <Image
            src="/qris.jpg"
            alt="QRIS Donation"
            fill
            className="object-cover"
            priority
          />
        </div>

        <p className="mt-4 text-xs font-medium" style={{ color: "#884444" }}>
          Yuk, dukung kami dengan scan QRIS di atas!
        </p>

        {/* Close Button */}
        <div className="mt-6 w-full">
          <button
            onClick={() => setIsVisible(false)}
            disabled={countdown > 0}
            className="w-full py-3 px-4 rounded-xl font-bold transition-all duration-300 flex items-center justify-center gap-2"
            style={
              countdown > 0
                ? { background: "#1a0000", color: "#664444", cursor: "not-allowed", border: "1px solid #330000" }
                : {
                    background: "linear-gradient(135deg, #cc0000 0%, #880000 50%, #440000 100%)",
                    color: "#ffffff",
                    boxShadow: "0 4px 20px rgba(180,0,0,0.4)",
                    border: "none"
                  }
            }
          >
            {countdown > 0 ? (
              <>
                <svg className="animate-spin h-5 w-5" style={{ color: "#664444" }} xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Tutup dalam {countdown}s
              </>
            ) : (
              "Lanjut Nonton"
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
