/**
 * NetShort Crypto Helper
 * Reverse engineered from NetShort webpack bundle (module 97539)
 * 
 * AES ECB + PKCS7, keys hardcoded in their source:
 * - Request key: "d8HCWwa9J0RENcRAYE32MKKwyH1f7Zf7"
 * - Fallback key: "5k3KYTOO9jnO0CeyGhdHc3pIjGnVgrMN"
 */

import CryptoJS from "crypto-js";

const AES_KEY_REQUEST = "d8HCWwa9J0RENcRAYE32MKKwyH1f7Zf7";
const AES_KEY_FALLBACK = "5k3KYTOO9jnO0CeyGhdHc3pIjGnVgrMN";

/**
 * Encrypt data with AES ECB PKCS7
 * Used for generating the encrypt-key header value
 */
export function aesEncrypt(data: string, key: string = AES_KEY_REQUEST): string {
  const keyParsed = CryptoJS.enc.Utf8.parse(key);
  const encrypted = CryptoJS.AES.encrypt(data, keyParsed, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return encrypted.toString();
}

/**
 * Decrypt AES ECB PKCS7 encrypted data
 * Used for decrypting the response body
 */
export function aesDecrypt(encryptedData: string, key: string): string {
  const keyParsed = CryptoJS.enc.Utf8.parse(key);
  const decrypted = CryptoJS.AES.decrypt(encryptedData, keyParsed, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return decrypted.toString(CryptoJS.enc.Utf8);
}

/**
 * Generate encrypt-key header value (wD function from bundle)
 * = base64url(AES_encrypt(data, fixedKey))
 */
export function generateEncryptKey(data: string): string {
  const key = CryptoJS.enc.Utf8.parse(AES_KEY_REQUEST);
  const encrypted = CryptoJS.AES.encrypt(data, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7,
  });
  return btoa(encrypted.toString())
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=/g, "");
}

/**
 * Decrypt response: parse encrypt-key header → AES key → decrypt body
 */
export function decryptResponse(body: string, encryptKeyHeader: string): string {
  try {
    // The encrypt-key header from response is base64 of AES-encrypted AES key
    const decoded = Buffer.from(encryptKeyHeader, "base64").toString("utf8");
    // Try decrypt with request key first
    try {
      const aesKey = aesDecrypt(decoded, AES_KEY_REQUEST);
      if (aesKey && aesKey.length > 0) {
        return aesDecrypt(body, aesKey);
      }
    } catch {
      // fallback
    }
    // Try with fallback key
    const aesKey2 = aesDecrypt(decoded, AES_KEY_FALLBACK);
    return aesDecrypt(body, aesKey2);
  } catch (e) {
    // If decryption fails, try parse as plain JSON
    return body;
  }
}

/**
 * Standard headers for NetShort API requests
 */
export const NETSHORT_HEADERS = {
  "Content-language": "en_US",
  "Content-Type": "application/json;charset=utf-8",
  "OS": "4",
  "canary": "v1",
};

/**
 * Make a request to NetShort API with proper crypto handling
 */
export async function netshortFetch(
  path: string,
  options: { method?: string; body?: any } = {}
): Promise<any> {
  const url = `https://netshort.com/prod-web-api${path}`;
  const method = options.method || "GET";

  // Generate encrypt-key for request header
  const encryptKey = generateEncryptKey(path);

  const fetchOptions: RequestInit = {
    method,
    headers: {
      ...NETSHORT_HEADERS,
      "encrypt-key": encryptKey,
    },
    cache: "no-store",
  };

  if (options.body && method !== "GET") {
    (fetchOptions as any).body = JSON.stringify(options.body);
  }

  const response = await fetch(url, fetchOptions);

  if (!response.ok) {
    throw new Error(`NetShort API error: ${response.status}`);
  }

  const responseText = await response.text();
  const responseEncryptKey = response.headers.get("encrypt-key") || response.headers.get("Encrypt-Key");

  // Try to decrypt response if encrypt-key present
  if (responseEncryptKey) {
    try {
      const decrypted = decryptResponse(responseText, responseEncryptKey);
      if (decrypted) return JSON.parse(decrypted);
    } catch {
      // fall through to plain parse
    }
  }

  // Try plain JSON
  try {
    return JSON.parse(responseText);
  } catch {
    throw new Error("Failed to parse NetShort response");
  }
}
