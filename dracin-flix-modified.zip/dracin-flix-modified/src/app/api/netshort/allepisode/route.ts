import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { nsAllEpisode } from "@/lib/netshort-api";

export const dynamic = 'force-dynamic';

/**
 * GET /api/netshort/allepisode?shortPlayId=xxx
 * Mengambil semua link stream episode drama dari NetShort via Sansekai API
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const shortPlayId = searchParams.get("shortPlayId");

    if (!shortPlayId) {
      return encryptedResponse({ success: false, error: "shortPlayId is required" }, 400);
    }

    const data = await nsAllEpisode(shortPlayId);

    const raw = data?.data || data;
    const episodeList = raw?.shortPlayEpisodeInfos
      || raw?.episodeList
      || raw?.episodes
      || [];

    const episodes = episodeList.map((ep: any) => ({
      episodeId: ep.episodeId || ep.id,
      episodeNo: ep.episodeNo || ep.episode || ep.no,
      cover: ep.episodeCover || ep.cover || "",
      videoUrl: ep.playVoucher || ep.videoUrl || ep.streamUrl || ep.url || "",
      quality: ep.playClarity || ep.quality || "720p",
      isLock: ep.isLock ?? false,
      likeNums: ep.likeNums || ep.likes || "0",
      subtitleUrl: ep.subtitleList?.[0]?.url || ep.subtitleUrl || "",
    }));

    return encryptedResponse({
      success: true,
      shortPlayId: raw?.shortPlayId || shortPlayId,
      title: raw?.shortPlayName || raw?.title,
      totalEpisodes: raw?.totalEpisode || raw?.totalEpisodes || episodes.length,
      episodes,
    });
  } catch (error) {
    console.error("NetShort AllEpisode Error:", error);
    return encryptedResponse({ success: false, error: "Internal server error" });
  }
}
