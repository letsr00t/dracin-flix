import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { nsForYou } from "@/lib/netshort-api";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const data = await nsForYou();

    const list = data?.data || data || [];
    let dramas: any[] = [];

    if (Array.isArray(list)) {
      list.forEach((group: any) => {
        const items = group.contentInfos || group.shortPlayList || group.dramas || [];
        items.forEach((item: any) => {
          dramas.push({
            shortPlayId: item.shortPlayId,
            shortPlayLibraryId: item.shortPlayLibraryId,
            title: item.shortPlayName || item.title,
            cover: item.shortPlayCover || item.groupShortPlayCover || item.cover,
            labels: item.labelArray || item.labelNameList || item.labels || [],
            heatScore: item.heatScoreShow || item.heatScore || "",
            scriptName: item.scriptName,
          });
        });
      });
    }

    // Deduplicate by shortPlayId
    const seen = new Set();
    dramas = dramas.filter((d) => {
      if (seen.has(d.shortPlayId)) return false;
      seen.add(d.shortPlayId);
      return true;
    });

    return encryptedResponse({
      success: true,
      data: dramas,
      completed: true,
    });
  } catch (error) {
    console.error("NetShort ForYou Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
