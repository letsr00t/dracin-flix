import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { nsSearch } from "@/lib/netshort-api";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get("query");

    if (!query) return encryptedResponse({ success: true, data: [] });

    const data = await nsSearch(query);

    const results = data?.data?.searchCodeSearchResult
      || data?.searchCodeSearchResult
      || data?.data
      || data?.results
      || [];

    const normalizedResults = (Array.isArray(results) ? results : []).map((item: any) => ({
      shortPlayId: item.shortPlayId,
      shortPlayLibraryId: item.shortPlayLibraryId,
      title: (item.shortPlayName || item.title || "").replace(/<\/?em>/g, ""),
      cover: item.shortPlayCover || item.cover,
      labels: item.labelNameList || item.labelArray || item.labels || [],
      heatScore: item.formatHeatScore || item.heatScoreShow || item.heatScore || "",
      description: item.shotIntroduce || item.description || "",
    }));

    return encryptedResponse({ success: true, data: normalizedResults });
  } catch (error) {
    console.error("NetShort Search Error:", error);
    return encryptedResponse({ success: true, data: [] });
  }
}
