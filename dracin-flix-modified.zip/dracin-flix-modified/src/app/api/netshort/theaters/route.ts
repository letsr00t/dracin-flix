import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { nsTheaters } from "@/lib/netshort-api";

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const data = await nsTheaters();

    const list = data?.data || data || [];
    const normalizedGroups = Array.isArray(list) ? list.map((group: any) => ({
      groupId: group.groupId || group.labelId || group.id,
      groupName: group.contentName || group.labelName || group.groupName || group.name,
      contentRemark: group.contentRemark || group.remark || "",
      dramas: (group.contentInfos || group.shortPlayList || group.dramas || []).map((item: any) => ({
        shortPlayId: item.shortPlayId,
        shortPlayLibraryId: item.shortPlayLibraryId,
        title: item.shortPlayName || item.title,
        cover: item.shortPlayCover || item.groupShortPlayCover || item.cover,
        labels: item.labelArray || item.labels || [],
        heatScore: item.heatScoreShow || item.heatScore || "",
        scriptName: item.scriptName,
        totalEpisodes: item.totalEpisode || item.totalEpisodes || 0,
      })),
    })) : [];

    return encryptedResponse({ success: true, data: normalizedGroups });
  } catch (error) {
    console.error("NetShort Theaters Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
