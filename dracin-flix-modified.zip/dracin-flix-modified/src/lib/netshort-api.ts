/**
 * NetShort API Helper
 * Menggunakan proxy drama.sansekai.my.id sebagai wrapper resmi
 * Docs: https://drama.sansekai.my.id/api-docs
 */

const BASE_URL = "https://drama.sansekai.my.id";

async function sansekaiFetch(path: string): Promise<any> {
  const url = `${BASE_URL}${path}`;
  const response = await fetch(url, {
    headers: {
      "Content-Type": "application/json",
    },
    cache: "no-store",
  });

  if (!response.ok) {
    throw new Error(`Sansekai API error: ${response.status} - ${url}`);
  }

  const text = await response.text();
  if (!text || !text.trim()) {
    throw new Error(`Empty response from: ${url}`);
  }

  try {
    return JSON.parse(text);
  } catch {
    throw new Error(`Invalid JSON from: ${url}`);
  }
}

/**
 * GET /netshort/foryou — Konten For You / rekomendasi
 */
export async function nsForYou(): Promise<any> {
  return sansekaiFetch("/netshort/foryou");
}

/**
 * GET /netshort/theaters — Halaman daftar theater/drama
 */
export async function nsTheaters(): Promise<any> {
  return sansekaiFetch("/netshort/theaters");
}

/**
 * GET /netshort/search?query=... — Pencarian drama
 */
export async function nsSearch(query: string): Promise<any> {
  return sansekaiFetch(`/netshort/search?query=${encodeURIComponent(query)}`);
}

/**
 * GET /netshort/allepisode?shortPlayId=... — Semua episode + stream URL
 */
export async function nsAllEpisode(shortPlayId: string): Promise<any> {
  return sansekaiFetch(`/netshort/allepisode?shortPlayId=${shortPlayId}`);
}
