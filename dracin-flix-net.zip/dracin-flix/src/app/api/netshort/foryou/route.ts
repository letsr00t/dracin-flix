import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const page = searchParams.get("page") || "1";

    const data = await netshortFetch(`/web/v4/short_play/home?page=${page}`);

    const contentInfos = data?.data?.contentInfos || data?.contentInfos || [];
    const dramas = contentInfos.map((item: any) => ({
      shortPlayId: item.shortPlayId,
      shortPlayLibraryId: item.shortPlayLibraryId,
      title: item.shortPlayName,
      cover: item.shortPlayCover,
      labels: item.labelArray || item.labelList?.map((l: any) => l.labelName) || [],
      heatScore: item.heatScoreShow || "",
      scriptName: item.scriptName,
    }));

    return encryptedResponse({
      success: true,
      data: dramas,
      maxOffset: data?.data?.maxOffset ?? data?.maxOffset,
      completed: data?.data?.completed ?? data?.completed,
    });
  } catch (error) {
    console.error("NetShort ForYou Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
