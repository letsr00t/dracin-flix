import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const query = searchParams.get("query");

    if (!query) return encryptedResponse({ success: true, data: [] });

    const data = await netshortFetch(
      `/web/v4/short_play/search?keyword=${encodeURIComponent(query)}&page=1`
    );

    const results = data?.data?.searchCodeSearchResult || data?.searchCodeSearchResult || data?.data || [];
    const normalizedResults = results.map((item: any) => ({
      shortPlayId: item.shortPlayId,
      shortPlayLibraryId: item.shortPlayLibraryId,
      title: (item.shortPlayName || "").replace(/<\/?em>/g, ""),
      cover: item.shortPlayCover,
      labels: item.labelNameList || item.labelArray || [],
      heatScore: item.formatHeatScore || item.heatScoreShow || "",
      description: item.shotIntroduce,
    }));

    return encryptedResponse({ success: true, data: normalizedResults });
  } catch (error) {
    console.error("NetShort Search Error:", error);
    return encryptedResponse({ success: true, data: [] });
  }
}
