import { NextRequest } from "next/server";
import { encryptedResponse } from "@/lib/api-utils";
import { netshortFetch } from "@/lib/netshort-crypto";

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const data = await netshortFetch(`/web/v4/short_play/detail_info/cascade_label`);

    const list = data?.data || data || [];
    const normalizedGroups = list.map((group: any) => ({
      groupId: group.groupId,
      groupName: group.contentName || group.groupName,
      contentRemark: group.contentRemark,
      dramas: (group.contentInfos || []).map((item: any) => ({
        shortPlayId: item.shortPlayId,
        shortPlayLibraryId: item.shortPlayLibraryId,
        title: item.shortPlayName,
        cover: item.shortPlayCover || item.groupShortPlayCover,
        labels: item.labelArray || [],
        heatScore: item.heatScoreShow || "",
        scriptName: item.scriptName,
        totalEpisodes: item.totalEpisode || 0,
      })),
    }));

    return encryptedResponse({ success: true, data: normalizedGroups });
  } catch (error) {
    console.error("NetShort Theaters Error:", error);
    return encryptedResponse({ success: false, data: [] });
  }
}
